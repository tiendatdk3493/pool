package com.tma.gbst.model;

public enum Role {
    ROLE_ADMIN, ROLE_USER
}
