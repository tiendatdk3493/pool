package com.tma.gbst.repository;

import com.tma.gbst.model.Course;
import org.springframework.stereotype.Repository;

/**
 * Created by P550 on 5/5/2015.
 */
public interface CourseRepository extends MyBaseRepository<Course, Integer> {
}
